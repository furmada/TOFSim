# TOFSim
## Simulating the Time-of-Flight Mass Spectrometer

Please see `Final Project.ipynb` to start.

View the result graphics in the `Graphics` folder.